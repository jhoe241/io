<?php
/*
Template Name: Google Adwords
*/
?>
<?php get_header(); ?>

<div id="hero-image" style="background-position: center top; background-image:url('<?php echo get_the_post_thumbnail_url(); ?>');">
	<h1><?php the_title();?></h1>
	
		
		<div class="single-wrap">
		<ul id="hero-nav">
			<?php wp_nav_menu(array('menu' => 'Digital Marketing')); ?>
		</ul>
		</div>
	
	</div>
</div>


	<div class="site-inner text-center">
		<img class="text-center" src="/wp-content/themes/ionline/images/google-adwords-img.jpg" alt="" />
	
	
	<div class="white-bg">
	
	<h4>Google AdWords</h4>
	
	<p>iOnline’s SEO services provide research, analysis and recommendations for all websites, but especially for those having difficulty with their Search Engine visibility.</p>

	<p>If you want to increase your business ROI and know what you’re spending on online marketing is working, then we can tailor a solution for you. Every service iOnline provides, from Adwords, SEO, Remarketing and Facebook Advertising, is tracked and reported back to you. </p>

	<p>Whether you’re looking to bring in new website visits, grow online sales, get the phones ringing or keep customers coming back for more, iOnline can manage your Adwords campaign to generate and maintain the growth of your leads and in turn increase your businesses ROI.</p>
	
	</div>
	
	<div class="white-bg">
	
		<img class="text-center" src="/wp-content/themes/ionline/images/shake-hand.jpg" alt="" />
		
		<h3>Reach the right people at the right time</h3>
		
		<p>iOnline will ensure your business gets found by people on Google precisely when they’re searching for the product and/or service that you offer.</p>
		
	</div>
	
	
	<img class="text-center" src="/wp-content/themes/ionline/images/google-adwords-img2.jpg" alt="" />
	
	<div class="orange-bg text-center">
	
		<h4>Over a million businesses rely on Google AdWords. </h4>
		<a href="#"> Find Out Way</a>
	
	</div>
	
	<div class="white-bg">
		<h4>Get your business found</h4>
		
		<p>Whether you’re looking to attract new website visitors, grow online sales, get the phones ringing or keep customers coming back for more, iOnline can manage and track your Google AdWords to get you the ROI your need to grow and maintain your business.</p>
		
		<div class="grey-bar"></div>
		
	</div>
	
	<div id="connects">
		<div class="single-wrap">
			<div class="col-md-6 col-sm-12">
				<div class="col-md-6 col-sm-12">
					<h4>Connect with customers across the web</h4>
				</div>
				<div class="col-md-6 col-sm-12">
					<p>You can reach the right customers on relevant websites across the web. </p>

					<p>A range of options lets you target by website type, audience type or remarketing, when and where it matters.</p>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<div class="col-md-6 col-sm-12">
					<h4>Measurable, accountable, flexible – take  the guesswork out of your marketing</h4>
				</div>
				<div class="col-md-6 col-sm-12">
					<p>Google AdWords shows how many people notice your ads and what percentage click to visit your website.</p>

					<p>With tracking tools you can even see the actual sales your website is generating as a direct result of your ads.</p>
				</div>
			</div>
		
		</div>
	</div>
	
	
	</div><!-- site-inner -->



<?php get_footer(); ?>