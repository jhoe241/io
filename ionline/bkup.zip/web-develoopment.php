<?php
/*
Template Name: Web Development
*/
?>
<?php get_header(); ?>

<?php echo do_shortcode('[parallax-scroll id="97"]'); ?>

<div id="single-top">
	<div class="wrap">

		<h4>Prefer to speak someone local? Have a specific question about our services?</h4>
		<p>Speak with one of our consultants now. Choose your preferred contact method.</p>

			<div class="col-lg-4 col-md-3">
			</div><!-- col-lg-4 -->
			
			<div class="col-lg-4 col-md-4 st-buttons">

					<div class="col-md-6 col-sm-6 text-center">
						<a class="orange-button" href="tel:1800466546">Call Us Now</a>
					</div>
				
					<div class="col-md-6 col-sm-6 text-center">
						<a class="orange-button" href="/contact">Ask a local</a>
					</div>

			</div><!-- col-lg-4 -->
			
			<div class="col-lg-4 col-md-3">
			</div><!-- col-lg-4 -->
			
	
		
	</div><!-- wrap -->	
</div><!-- single top -->

<div class="wrap1100">
	
	
	<?php	$grp = get_field('website_design'); ?>
		
	<div class="row nopadding" style="background-image:url('<?php echo $grp['website_design_banner'] ?>'); background-size:cover; min-height:349px;">
	</div>
	
	<div class="row nopadding row-eq-height">
		<div class="col-lg-8 col-md-1 col-sm-12 orange-bg no">

				<?php echo ($grp["content"]); ?>
		
		</div>
		<div class="col-lg-4 col-md-3 col-sm-12 center-align">
			
			<img class="hide-mobile" src="<?php echo $grp['icon'] ?>" alt="<?php echo $hero['image']['alt']; ?>" />
			
		</div>
	</div>

	<div class="row row-eq-height">
	
		<?php	$wp = get_field('wordpress'); ?>	
	

		<div class="col-lg-6 col-md-6 col-sm-12" style="background-image:url('<?php echo $wp['wordpress_banner'] ?>'); background-size:cover;">
		
		</div>
		<div class="col-lg-6 col-md-6 col-sm-12">
		 
			<div class="white-bg">
			
			
			<?php echo ($wp["wordpress_content"]); ?>

				
			</div><!-- white-bg -->
		</div>
	</div>
	
	<div class="row row-eq-height" style="position:relative">
	
	<?php	$ec = get_field('e-commerce'); ?>	
	
		<div class="col-lg-7 col-md-6 col-sm-12 nopadding">
		
			<div class="white-bg">
			
				<?php echo ($ec["e_commerce_content"]); ?>
		
			</div><!-- white-bg -->
			
			<img class="bottom-align hide-mobile" src="<?php echo $ec['e_commerce_icon'] ?>" alt="<?php echo $hero['image']['alt']; ?>" />

		</div>
		<div class="col-lg-5 col-md-6 col-sm-12 nopadding">

			<img src="<?php echo $ec['e_commerce_banner'] ?>" alt="<?php echo $hero['image']['alt']; ?>" />			
			
		</div>
	</div>
	
	
	<div class="row row-eq-height" style="position:relative">
	
	<?php	$hds = get_field('hosting_&_domain_services'); ?>	
	
		<div class="col-lg-4 col-md-4 col-sm-12 nopadding">
		
			<img src="<?php echo $hds['hosting_&_domain_services_banner'] ?>" alt="<?php echo $hero['image']['alt']; ?>" />	

		</div>
		<div class="col-lg-8 col-md-8 col-sm-12 nopadding ">

			<div class="white-bg">
			
				<?php echo ($hds["hosting_&_domain_services_content"]); ?>

			</div><!-- white-bg -->
				
				<img class="bottom-align hide-mobile" src="<?php echo $hds['hosting_&_domain_services_icon'] ?>" alt="<?php echo $hero['image']['alt']; ?>" />
			
		</div>
	</div>
	
	<div class="row nopadding row-eq-height">
		<?php	$wdb = get_field('web_development_botoom'); ?>	
		
		<div class="col-lg-7 col-md-6 col-sm-12 orange-bg">
		
				<?php echo ($wdb["referral_partners_content"]); ?>

		</div>
		<div style="background-image:url('<?php echo $wdb['referral_partners_banner'] ?>'); background-size:cover" class="col-lg-5 col-lg-6 col-sm-12 nopadding">
				
			
		</div>
	</div>
	<div id="contact-information">
		<div class="row padding-60 text-center ">
			
			<?php echo ($wdb["contact_infromation"]); ?>
		
		</div>
	</div>
		
</div><!-- wrap1100 -->

<?php get_footer(); ?>
